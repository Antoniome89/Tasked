
from flask import Flask, render_template, request, redirect, url_for
from models import Tarea
import db

app = Flask(__name__) #la variable app contiene el servidor web de Flask

#Vinculación entre Python y nuestro navegador:
@app.route("/")
def home():
    todas_tareas= db.session.query(Tarea).all() # La variable todas_tareas contiene todas las tareas almacenadas en la base de datos.
    return render_template("index.html", lista_tareas = todas_tareas) # Vinculamos Python con index html, no es necesario decirle la ruta porque Flask ya sabe que la carpeta es templates.

@app.route("/crear-tarea", methods=["POST"])
def crear():
    tarea = Tarea(contenido=request.form["contenido_tarea"], hecha=False, categoria=request.form["categoria_tarea"]) # id no es necesario asignarlo manualmente, porque la primary key se genera automáticamente
    db.session.add(tarea) # Añadir el objeto de Tarea a la base de datos
    db.session.commit() # Ejecutar la operación pendiente de la base de datos
    return redirect(url_for("home"))

@app.route("/eliminar-tarea/<id>")
def eliminar(id):
    tarea = db.session.query(Tarea).filter_by(id=int(id)).delete()
    db.session.commit()
    return redirect(url_for('home'))

@app.route("/tarea-hecha/<id>")
def hecha(id):
    tarea = db.session.query(Tarea).filter_by(id=int(id)).first()
    tarea.hecha = not(tarea.hecha)
    db.session.commit()
    return redirect(url_for("home"))

if __name__ == "__main__":
    db.Base.metadata.create_all(db.engine)
    app.run(debug=True) # debug = True hace que cada vez que reiniciemos el servidor o hagamos un cambio, se reinicie.

