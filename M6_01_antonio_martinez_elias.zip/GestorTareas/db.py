from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker
from sqlalchemy.ext.declarative import declarative_base

#El engine permite a SQLAlchemy comunicarse con la base de datos en un dialecto concreto.
#https://docs.sqlalchemy.org/en/14/core/engines.html -> aquí puedo ver los dialectos aceptados por sqlalchemy
engine = create_engine('sqlite:///database/tareas.db', connect_args={'check_same_thread': False}) #En qué dialecto hablamos y donde/nombre de bbdd? bd trabaja en segundo plano con connect_args = False.
#Advertencia, crear el engine no conecta directamente con la base de datos.

#Objeto "sesión" que realiza las transacciones dentro de la base de datos
Session = sessionmaker(bind=engine) #Esto crea una clase, por eso le ponemos el nombre en mayúsculas.
session = Session() #Creamos el objeto de la clase anterior

#Ahora vamos al fichero models.py en los modelos (clases) donde queremos que se tranformen
#en la tabla le añadiremos esta variable y esto se encargará de mapear y vincular cada clase a cada tabla
Base = declarative_base()